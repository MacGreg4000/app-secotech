'use strict'
module.exports = {
  ...require('.prisma/client/sql'),
}
