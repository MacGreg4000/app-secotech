export * from '.prisma/client/sql'
