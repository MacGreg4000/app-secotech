module.exports = {
  ...require('.prisma/client/default'),
}
