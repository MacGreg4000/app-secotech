export * from '.prisma/client/default'
